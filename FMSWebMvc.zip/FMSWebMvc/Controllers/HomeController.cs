﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using FMS.Model.Model;
using FMS.Web.Mvc.Models;
using FMS.BL.Business;

namespace FMS.Web.Mvc.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(HttpPostedFileBase Uploadfile)
        {
            List<Participated_User> model = new List<Participated_User>();
            if (Request.Files["Uploadfile"].ContentLength > 0)
            {
                string fileExtension =
                                     System.IO.Path.GetExtension(Request.Files["Uploadfile"].FileName);

                if (fileExtension == ".xls" || fileExtension == ".xlsx")
                {
                    string fileLocation = Server.MapPath("~/Content/") + Request.Files["Uploadfile"].FileName;
                    if (System.IO.File.Exists(fileLocation))
                    {

                        System.IO.File.Delete(fileLocation);
                    }
                    Request.Files["Uploadfile"].SaveAs(fileLocation);
                    FileInfo file = new FileInfo(fileLocation);
                    model = ParticipateDetails.GetExcelDetails(file);
                    Session["EmailTo"] = model.Select(t => t.EmployeeEmail).ToList();
                }

            }
            return View(model);
        }

        [HttpPost]
        public bool SentEmail()
        {
            List<string> toemail = (List<string>)Session["EmailTo"];
            var emailDetails = new EmailDetails
            {
                From="sen10290@gmail.com",
                Body="FMS System",
                FeedbackBody="https://www.google.com",
                Subjest="Welcome to FMS System"
            };
            return ExcelToEmailBL.SendEmail(toemail,emailDetails);
        }


    }
}