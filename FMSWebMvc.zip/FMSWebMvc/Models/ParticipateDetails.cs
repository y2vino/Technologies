﻿using FMS.Model.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using OfficeOpenXml;

namespace FMS.Web.Mvc.Models
{
    public class ParticipateDetails
    {
        public static List<Participated_User> GetExcelDetails(FileInfo file)
        {
            var returnVal = new List<Participated_User>();
            try
            {
                using (ExcelPackage package = new ExcelPackage(file))
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets["FMSParticipentDetails"];
                    if (worksheet != null)
                    {
                        returnVal = worksheet.ConvertTableToObjects<Participated_User>()?.ToList();
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return returnVal;
        }
    }
}