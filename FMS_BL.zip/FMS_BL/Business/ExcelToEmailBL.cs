﻿using FMS.Model.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace FMS.BL.Business
{
    public class ExcelToEmailBL
    {
        public static bool SendEmail(List<string> toemailid, EmailDetails emaildetails)
        {
            var returnVal = false;
            foreach (var item in toemailid)
            {

                using (MailMessage smtpMail = new MailMessage
                    (emaildetails.From, item))
                {


                    smtpMail.Body = emaildetails.Body + "Click here to give Feedback" + emaildetails.FeedbackBody;
                    
                    smtpMail.Subject = emaildetails.Subjest;
                   
                    SmtpClient smtpClient = new SmtpClient();

                    smtpClient.Send(smtpMail);
                    returnVal = true;
                }
            }
            return returnVal;

        }
    }
}
