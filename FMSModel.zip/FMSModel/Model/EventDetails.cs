﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMS.Model.Model
{
    public class EventDetails
    {
        public string EventID { get; set; }
        public string BaseLocation { get; set; }
        public bool BeneficiaryName { get; set; }
        public string CouncilName { get; set; }
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public string EventDate { get; set; }
    }
}
