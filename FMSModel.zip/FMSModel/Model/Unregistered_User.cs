﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FMS.Model.Model
{
    public class Unregistered_User
    {
        public string EventID { get; set; }
        public string BaseLocation { get; set; }
        public string EventName { get; set; }
        public string EventDate { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeEmail { get; set; }
    }
}
